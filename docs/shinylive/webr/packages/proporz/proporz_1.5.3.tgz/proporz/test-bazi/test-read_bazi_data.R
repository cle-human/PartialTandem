# BAZI Dataset (data.zip) available from:
# https://www.tha.de/Geistes-und-Naturwissenschaften/Data-Science/BAZI.html
# Direct URL: https://www.tha.de/Binaries/Binary78393/data.zip
# Extract to "data/" folder

bazi_files = list.files("data",
                        full.names = TRUE,
                        recursive = TRUE,
                        pattern = "\\.bazi$")

for(.bazi_file in bazi_files) {
    bd = testthat::expect_no_condition(read_bazi(.bazi_file))
    testthat::expect_s3_class(bd$data, "data.frame")
    testthat::expect_true(length(bd$seats) >= 1)
}
